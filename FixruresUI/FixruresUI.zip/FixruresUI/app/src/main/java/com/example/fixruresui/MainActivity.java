package com.example.fixruresui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ArrayList<String> sportList = new ArrayList<>();
    TextAdapter textAdapter;
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        textAdapter = new TextAdapter();
        recyclerView.setAdapter(textAdapter);
        sportList.add("Athletics");
        sportList.add("Badminton(Mixed)");
        sportList.add("Basketball(Boys)");
        sportList.add("Basketball(Girls)");
        sportList.add("Carrom");
        sportList.add("Chess");
        sportList.add("Cricket(Boys)");
        sportList.add("Cricket(Girls)");
        sportList.add("Football(Boys)");
        sportList.add("Handball(Boys)");
        sportList.add("Handball(Girls)");
        sportList.add("Hockey(Boys)");
        sportList.add("Kabaddi");
        sportList.add("Kho Kho(Boys)");
        sportList.add("Kho Kho(Girls)");
        sportList.add("Marathon");
        sportList.add("Powerlifting");
        sportList.add("Swimming");
        sportList.add("Table Tennis(Mixed)");
        sportList.add("Tennis(Boys)");
        sportList.add("Throwball");
        sportList.add("Volleyball(Boys)");
        sportList.add("Volleyball(Girls)");
        sportList.add("SportsQuiz");
        makeList();

    }

    private void makeList(){
        textAdapter.setItems(sportList);
    }
}
